#simple configuration
env = {}
env['host'] = '0.0.0.0'
env['port'] = 3000
